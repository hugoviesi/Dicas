# RefitExample
Implementação de um Console Application realizando consumo de uma API utilizando Refit.
